"use strict";(self.webpackChunkdig=self.webpackChunkdig||[]).push([[3683],{63683:(e,i,a)=>{a.r(i),a.d(i,{default:()=>I});var l=a(75492),n=a(40254),t=a(68096),r=a(38792),s=a(72791),o=a(39230),d=a(17939),c=a(92706),m=a(74424),p=a(87309),x=a(23853),u=a.n(x),h=a(45702),f=a(99887),v=a(62075),g=a(16871),b=a(60868),y=a(46156),j=a(89501),N=a(80184);const k=d.ZP.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  @media ${v.U.mobileL} {
    flex-direction: column;
    align-items: flex-start;
  }
  .title {
    text-align: center;
    font-size: 20px;
    font-family: "Inter";
    font-style: normal;
    font-weight: 600;
    line-height: 32px;
    letter-spacing: -0.18px;
    padding-left: 15rem;
    @media ${v.U.mobileL} {
      padding-left: 1rem;
      margin-top: 1rem;
    }
  }

  .back {
    display: flex;
    gap: 10px;
    align-items: center;
    font-size: 14px;
    font-family: "Inter";
    font-style: normal;
    font-weight: 600;
    line-height: 16px;
    letter-spacing: 0.25px;
    text-transform: capitalize;
    cursor: pointer;
  }
`,w=d.ZP.div`
  background: #fff;
  margin-top: 48px;
  max-width: 50%;
  margin-inline: auto;
  padding: 24px 24px 56px 24px;
  @media ${v.U.mobileL} {
    max-width: 100%;
    padding: 1rem;
  }
  .form {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    align-items: flex-start;
    gap: 1rem;
    border-radius: 0px 0px 16px 16px;

    @media ${v.U.mobileL} {
      grid-template-columns: repeat(1, 1fr);
    }
  }
`,Z=u().div`
  ${e=>(e=>"primary"===e.variant?"border-b-white":"secondary"===e.variant?"border-b-button-variants-secondary-loading-scene":"tertiary"===e.variant?"border-b-button-variants-tertiary-loading-scene":void 0)(e)}
  inline-block w-6 h-6 border-[1.7px] border-l-transparent border-r-transparent border-t-transparent rounded-full animate-spin`;const _=function(e){let{submit:i,loading:a,initialData:d}=e;const{t:x}=(0,o.$G)("inventory"),u=(0,g.s0)(),v=f.Z.getAssumedUser(),_=[{label:x("6-months"),value:"6"},{label:x("12-months"),value:"12"},{label:x("24-months"),value:"24"},{label:x("36-months"),value:"36"},{label:x("48-months"),value:"48"}],C=[{label:x("salary-earner"),value:"Salary Earner"},{label:x("business-owner"),value:"Business Owner"}],[S,$]=(0,s.useState)(_[0]),z=f.Z.getCountry(),[I,U]=(0,s.useState)((null===d||void 0===d?void 0:d.telephone)||""),[G,P]=(0,s.useState)((null===d||void 0===d?void 0:d.net_monthly_income)||""),[T,L]=(0,s.useState)((null===d||void 0===d?void 0:d.applicant_type)||C[0]),[E,q]=(0,s.useState)(""),[W,D]=(0,s.useState)({country:z,applicant_type:(null===d||void 0===d?void 0:d.applicant_type)||"",first_name:(null===d||void 0===d?void 0:d.first_name)||"",last_name:(null===d||void 0===d?void 0:d.last_name)||"",email:(null===d||void 0===d?void 0:d.email)||"",telephone:(null===d||void 0===d?void 0:d.telephone)||"",net_monthly_income:(null===d||void 0===d?void 0:d.net_monthly_income)||"",term:(null===d||void 0===d?void 0:d.term)||"",pre_qual_residual_value_percentage:"0.1"}),F=e=>i=>{D({...W,[e]:i.target.value})};return(0,s.useEffect)((()=>{var e,i,a;U(null!==d&&void 0!==d&&d.telephone?null===d||void 0===d||null===(e=d.telephone)||void 0===e?void 0:e.substring(null!==(i=null===(a=(0,y.u)(z))||void 0===a?void 0:a.length)&&void 0!==i?i:3):""),L(null===d||void 0===d?void 0:d.applicant_type),P(null===d||void 0===d?void 0:d.net_monthly_income),$(null===d||void 0===d?void 0:d.term)}),[z,d]),(0,N.jsxs)(N.Fragment,{children:[(0,N.jsxs)(k,{children:[(0,N.jsxs)("button",{onClick:()=>u(-1),className:"back",children:[(0,N.jsx)("img",{src:"https://media.autochek.africa/file/publicAssets/Icon-1.svg",alt:"chevron-back",style:{marginTop:"3px",marginRight:"10px"}}),x("back")]}),(0,N.jsx)("div",{className:"title",children:(0,N.jsx)("div",{children:x("pre-qualification-title")})}),(0,N.jsx)("div",{className:"form",children:(0,N.jsx)("div",{className:"container"})}),(0,N.jsx)("div",{className:"next"})]}),(0,N.jsxs)(w,{children:[(0,N.jsxs)("div",{className:"form",children:[(0,N.jsxs)(l.T8,{children:[(0,N.jsx)("div",{className:"label",children:x("first-name")}),(0,N.jsx)(n.Z,{id:"outlined-controlled",fullWidth:!0,placeholder:x("first-name"),onChange:F("first_name"),value:null===W||void 0===W?void 0:W.first_name})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsxs)("div",{className:"label",children:[x("last-name")," "]}),(0,N.jsx)(n.Z,{id:"outlined-controlled",fullWidth:!0,placeholder:x("last-name"),onChange:F("last_name"),value:null===W||void 0===W?void 0:W.last_name})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsxs)("div",{className:"label",children:[x("phone-number")," "]}),(0,N.jsx)(h.ov,{children:(0,N.jsx)(c.Z,{addonBefore:(0,N.jsx)("img",{src:(0,b.m)(z),alt:"flag"}),prefix:(0,y.u)(z),style:{width:"100%"},onChange:e=>{U(e)},keyboard:!1,placeholder:x("enter-phone-number"),value:I,min:0})})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsxs)("div",{className:"label",children:[x("email-address")," "]}),(0,N.jsx)(n.Z,{id:"outlined-controlled",fullWidth:!0,placeholder:x("enter-email-address"),inputProps:{pattern:"/^[0-9a-zA-Z]{15,17}$/"},onChange:F("email"),value:null===W||void 0===W?void 0:W.email})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsxs)("div",{className:"label",children:[x("next-monthly-income")," "]}),(0,N.jsx)(h.ov,{children:(0,N.jsx)(c.Z,{style:{width:"100%"},formatter:e=>(0,j.Z)(e),parser:e=>e.replace(/\$\s?|(,*)/g,""),onChange:e=>{P(e)},value:G,keyboard:!1,placeholder:x("enter-next-monthly-income")})})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsxs)("div",{className:"label",children:[x("upfront-payment")," "]}),(0,N.jsx)(h.ov,{children:(0,N.jsx)(c.Z,{style:{width:"100%"},formatter:e=>(0,j.Z)(e),parser:e=>e.replace(/\$\s?|(,*)/g,""),onChange:e=>{q(e)},value:E,keyboard:!1,placeholder:x("enter-upfront-payment")})})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsx)("div",{className:"label",children:x("loan-term")}),(0,N.jsx)(t.Z,{fullWidth:!0,children:(0,N.jsx)(r.Z,{fullWidth:!0,id:"bodyType",disablePortal:!0,options:_,value:S,onChange:(e,i)=>{$(i)},renderInput:e=>(0,N.jsx)(n.Z,{...e,placeholder:x("select-your-desired-loan-term")})})})]}),(0,N.jsxs)(l.T8,{children:[(0,N.jsx)("div",{className:"label",children:x("applicant-type")}),(0,N.jsx)(t.Z,{style:{justifyContent:"center",marginTop:"1rem"},fullWidth:!0,children:(0,N.jsx)(m.ZP.Group,{onChange:e=>{L(e.target.value)},value:T,children:C.map((e=>(0,N.jsx)(m.ZP,{value:e.value,children:e.label},e.label)))})})]})]}),(0,N.jsx)(l.T8,{children:(0,N.jsx)("div",{className:"loading-btn-container",children:(0,N.jsx)(p.ZP,{className:"loading-btn",type:"primary",onClick:async()=>{const e={...W};e.telephone=I?`${(0,y.u)(z)}${I}`:"",e.net_monthly_income=G,e.term=S.value,e.applicant_type=T,i(e)},disabled:!!v,children:a?(0,N.jsx)(Z,{variant:"secondary"}):x("submit")})})})]})]})};var C=a(72849);const S=d.ZP.div`
  display: flex;
  width: 45%;
  padding: 16px 69px;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  border-radius: 20px;
  border: 1px solid var(--divider-divider, #e5e7eb);
  background: #fff;
  box-shadow: 0px 8px 16px 0px rgba(96, 97, 112, 0.16);
  margin-inline: auto;
  @media ${v.U.mobileL} {
    width: 100%;
    padding: 1rem;
  }
  .header {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    justify-content: center;
    .image {
      width: 123px;
      height: 73px;
      margin-bottom: 1rem;
    }
    .title {
      font-family: "Inter";
      font-size: 20px;
      font-style: normal;
      font-weight: 600;
      line-height: 24px;
      letter-spacing: 0.15px;
      /* width: 100%; */
    }
    .subtitle {
      color: var(--typography-text-secondary, #6b7280);
      text-align: center;
      font-family: "Inter";
      font-size: 14px;
      font-style: normal;
      font-weight: 400;
      line-height: 24px;
      width: 80%;
      @media ${v.U.mobileL} {
        width: 100%;
      }
    }
  }
  .summary {
    display: flex;
    padding: 0px;
    align-items: flex-start;
    gap: 16px;
    align-self: stretch;
    margin-top: 1rem;
    @media ${v.U.mobileL} {
      flex-direction: column;
      padding: 1rem;
      justify-content: center;
      align-items: center;
    }
    .left {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 6px;
      flex: 1 0 0;
      @media ${v.U.mobileL} {
        align-items: center;
      }
    }
    .right {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 6px;
      flex: 1 0 0;
      @media ${v.U.mobileL} {
        align-items: center;
      }
    }
    .label {
      color: var(--grey-grey-dark, #4b5563);
      font-family: "Inter";
      font-size: 15px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
      text-transform: capitalize;
    }
    .value {
      color: var(--primary-primary-main, #30345e);
      font-family: "Inter";
      font-size: 28px;
      font-style: normal;
      font-weight: 600;
      line-height: normal;
    }
  }
  .details {
    display: flex;
    justify-content: space-between;
    align-items: center;
    align-self: stretch;
    gap: 10px;
    margin-top: 1rem;
    .label {
      color: var(--primary-primary-light, #7f83a8);
      font-family: "Inter";
      font-size: 16px;
      font-style: normal;
      font-weight: 400;
      line-height: normal;
    }
    .value {
      color: var(--primary-primary-main, #30345e);
      font-family: "Inter";
      font-size: 18px;
      font-style: normal;
      font-weight: 600;
      /* line-height: 40px; */
      text-transform: capitalize;
    }
  }
  .button-container {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 1rem;
    align-self: stretch;
    margin-block: 2rem;
    .outline-btn {
      cursor: pointer;
      display: flex;
      height: 40px;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      flex: 1 0 0;
      border-radius: 200px;
      border: 1px solid #000;
      color: var(--primary-main-color, #30345e);
      text-align: center;
      font-family: "Inter";
      font-size: 14px;
      font-style: normal;
      font-weight: 600;
      line-height: 24px;
      :hover {
        background: #fff;
      }
    }
    .solid-btn {
      display: flex;
      height: 40px;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      flex: 1 0 0;
      border-radius: 200px;
      background: var(--secondary-secondary-main, #ffb619);
      box-shadow: 0px 2px 4px 0px rgba(96, 97, 112, 0.16),
        0px 0px 1px 0px rgba(40, 41, 61, 0.04);
      color: var(--primary-main-color, #30345e);
      text-align: center;
      font-family: "Inter";
      font-size: 14px;
      font-style: normal;
      font-weight: 600;
      line-height: 24px;
    }
  }
`;const $=function(e){let{data:i,back:a}=e;const{t:l}=(0,o.$G)("inventory"),n=(0,g.s0)();return(0,N.jsxs)(S,{children:[(0,N.jsxs)("div",{className:"header",children:[(0,N.jsx)("div",{className:"image",children:(0,N.jsx)("img",{src:"/images/success.webp",alt:"checked"})}),(0,N.jsx)("h1",{className:"title",children:l("your-prequalification-status")}),(0,N.jsx)("h2",{className:"subtitle",children:l("your-prequalification-congratulations")})]}),(0,N.jsxs)("div",{className:"summary",children:[(0,N.jsxs)("div",{className:"left",children:[(0,N.jsx)("div",{className:"label",children:l("maximum-financeable-amount")}),(0,N.jsx)("div",{className:"value",children:(0,C.Z)((null===i||void 0===i?void 0:i.maxPrincipalDebt)||0,!0)})]}),(0,N.jsxs)("div",{className:"right",children:[(0,N.jsx)("div",{className:"label",children:l("minimum-financeable-amount")}),(0,N.jsx)("div",{className:"value",children:(0,C.Z)((null===i||void 0===i?void 0:i.minEquityContribution)||0,!0)})]})]}),(0,N.jsxs)("div",{className:"details",children:[(0,N.jsx)("div",{className:"label",children:l("maximum-monthly-installment")}),(0,N.jsx)("div",{className:"value",children:(0,C.Z)((null===i||void 0===i?void 0:i.totalMonthlyInstalment)||0,!0)})]}),(0,N.jsxs)("div",{className:"details",children:[(0,N.jsx)("div",{className:"label",children:l("maximum-finance-tenure")}),(0,N.jsxs)("div",{className:"value",children:[null===i||void 0===i?void 0:i.maxFinanceTerm," ",l("months")]})]}),(0,N.jsxs)("div",{className:"button-container",children:[(0,N.jsx)(p.ZP,{className:"outline-btn",onClick:a,type:"primary",size:"large",children:l("edit-preferences")}),(0,N.jsx)(p.ZP,{className:"solid-btn",onClick:()=>{n(`/inventory?price_high=${i.maxPrincipalDebt}`)},type:"primary",size:"large",children:l("view-eligible-cars")})]})]})};var z=a(29382);const I=function(){const[e,i]=(0,s.useState)(0),[a,l]=(0,s.useState)({}),[n,t]=(0,s.useState)(!1),[r,o]=(0,s.useState)({}),d=()=>{i(0)},c=async e=>{o(e),t(!0);try{const a=await z.Z.post("/v2/origination/loan/prequalification",e),n=JSON.parse(a.data);l(n),t(!1),i(1)}finally{t(!1)}};return 0===e?(0,N.jsx)(_,{initialData:r,loading:n,submit:c}):(0,N.jsx)($,{back:d,data:a})}},72849:(e,i,a)=>{a.d(i,{Z:()=>n});var l=a(99887);const n=(e,i)=>{if(void 0!==e&&0!==e){const a=null===e||void 0===e?void 0:e.toString(),n=Number(null===a||void 0===a?void 0:a.split(".")[0]);return`${i?(()=>{let e;switch(l.Z.getCountry()){case"NG":e="\u20a6 ";break;case"GH":e="GH\u20b5 ";break;case"KE":e="KSh ";break;case"CI":e="CFA ";break;case"UG":e="USh ";break;case"SN":e="XOF ";break;case"EG":e="EGP ";break;default:e=""}return e})():""}${n.toLocaleString("en-US")}`}return"---"}},89501:(e,i,a)=>{a.d(i,{Z:()=>l});const l=e=>("number"===typeof e?e:Number(e)).toLocaleString("en-US",{minimumFractionDigits:0})},46156:(e,i,a)=>{a.d(i,{u:()=>l});const l=e=>{let i;switch(e){case"NG":i="234";break;case"GH":i="233";break;case"KE":i="254";break;case"CI":i="225";break;case"UG":i="256";break;case"SN":i="221";break;case"EG":i="20"}return i}}}]);
//# sourceMappingURL=3683.39007e33.chunk.js.map